const BaseUrl = "https://awplconnectadmin.tgastaging.com";

export default {
  BaseUrl,
};
